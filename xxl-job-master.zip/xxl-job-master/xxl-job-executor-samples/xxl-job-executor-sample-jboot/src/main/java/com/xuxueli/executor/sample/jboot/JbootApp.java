package com.xuxueli.executor.sample.jboot;

import io.jboot.app.JbootApplication;

/**
 * Jboot app
 */
public class JbootApp {
    public static void main(String[] args) {
        JbootApplication.run(args);
    }
}
